<?php

namespace App\Http\Controllers;

use App\Models\userVerify;
use App\Models\users_tbl;
use Illuminate\Http\Request;

class ApiController extends Controller
{


}
