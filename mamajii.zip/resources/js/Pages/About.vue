<script setup>

import AppLayout from "@/Layouts/AppLayout.vue";
</script>

<template>
    <AppLayout title="درباره ما">
        <h1 class="text-2xl text-blue-500 text-center my-4 font-bold">درباره</h1>
    </AppLayout>
</template>

<style scoped>

</style>
