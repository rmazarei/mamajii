<script setup>

import AppLayout from "@/Layouts/AppLayout.vue";
</script>

<template>
    <AppLayout title="مقالات">
        <h1 class="text-2xl text-blue-500 text-center my-4 font-bold">مقالات</h1>
    </AppLayout>
</template>

<style scoped>

</style>
