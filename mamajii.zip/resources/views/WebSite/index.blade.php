<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>به ماماجی خوش آمدید</title>
    <link rel="icon" href="{{asset('admin-assets/images/logo.png')}}" type="image/gif" sizes="16x16">
</head>
<body style="background:#7248ee;">
    
    <div style="height:95vh;display:flex;justify-content: center;align-items: center;">

        <img src="{{asset('admin-assets/images/logo.png')}}" width="300px"/>
        
    </div>

</body>
</html>