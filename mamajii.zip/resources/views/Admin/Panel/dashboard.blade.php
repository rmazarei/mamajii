@include('Admin.Panel.Layouts.Panel')



        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="mdi mdi-home"></i>
                </span>
                {{__('all_strings.Dashboard')}}
              </h3>
            </div>
          </div>
          <!-- content-wrapper ends -->





          <!--Main Content Start-->
          <div>
          </div>
          <!--Main Content End-->








    @include('Admin.Panel.Layouts.Footer_Panel')
