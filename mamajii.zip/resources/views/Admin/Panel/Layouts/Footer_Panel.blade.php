<!-- partial:partials/_footer.html -->
<footer class="footer">
    <div class="container-fluid clearfix">
<!--
      <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Reza Farazi</span>
      <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"><a href="https://izino.ir/Post/%D8%B1%D8%B6%D8%A7%20%D9%81%D8%B1%D8%A7%D8%B2%DB%8C" target="_blank">Rezafta</a></span>
        -->
    </div>
  </footer>
  <!-- partial -->
</div>
<!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->











    <!--Iframe Dialog Start-->


    <div id="iframe_dialog" style="display: none;">
        <i class="mdi mdi-close" onclick="Close_Ifram_Dialog(this)"></i>
        <div id="iframe_dialog_main_content">
            <iframe id="iframe_dialog_main_content_iframe" src="http://google.com">

            </iframe>
        </div>
    </div>


    <!--Iframe Dialog End-->









    <!-- plugins:js -->
    <script src="{{asset('/admin-assets/vendors/js/vendor.bundle.base.js')}}"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="{{asset('/admin-assets/vendors/chart.js/Chart.min.js')}}"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="{{asset('/admin-assets/js/off-canvas.js')}}"></script>
    <script src="{{asset('/admin-assets/js/hoverable-collapse.js')}}"></script>
    <script src="{{asset('/admin-assets/js/misc.js')}}"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="{{asset('/admin-assets/js/dashboard.js')}}"></script>
    <script src="{{asset('/admin-assets/js/todolist.js')}}"></script>
    <!-- End custom js for this page -->
    <script src="{{asset('/admin-assets/js/main.js')}}"></script>
  </body>
</html>
