<!DOCTYPE html>
<html lang="fa">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Mamaji Panel</title>
    <link rel="stylesheet" href="{{asset('admin-assets/vendors/mdi/css/materialdesignicons.min.css')}}">
    <link rel="stylesheet" href="{{asset('admin-assets/vendors/css/vendor.bundle.base.css')}}">
    <link rel="stylesheet" href="{{asset('admin-assets/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('admin-assets/css/castum_style.css')}}">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="{{asset('admin-assets/images/ico.png')}}" />
  </head>
  <body>



