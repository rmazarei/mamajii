@include('WebSite.Layouts.Header')


<!--Main Content Start-->
<div id="error_content">

    <div>
        <img src="https://image.freepik.com/free-vector/404-error-with-icon-tab-wedsite-error_114341-27.jpg"/>
        <P>Hayla Sayfa Yoxumuz :)</P>
    </div>

</div>
<!--Main Content End-->

@include('WebSite.Layouts.Footer')